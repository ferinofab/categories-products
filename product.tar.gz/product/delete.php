<?php
/** @var PDO $pdo */
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/data_base/index.php';
$id = $_GET['id'];

$pdo->query("DELETE FROM products WHERE id = $id");

header('Location: /product');
?>

