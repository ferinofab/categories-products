<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$products= $pdo->query("SELECT * FROM `products` ORDER BY `date` DESC ")->fetchAll(PDO::FETCH_ASSOC);
$categoties = $pdo->query("SELECT * FROM `categories`")->fetchAll(PDO::FETCH_ASSOC);

$id_cat = $_GET['id']?? false;
$name_cat = $_GET['name']?? false;

$id_categories = $_POST['name']?? '';
var_dump($id_categories);

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Каталог товаров</h1>
<form action="products.php" method="post">
    <select name="name">
        <?php foreach ($categoties as $category):?>
            <option value="<?=$category['id']?>">
                <?= $category['name']?>
            </option>
        <?php endforeach;?>
    </select>
    <input type="submit" value="Применить">
</form>
<?php $flug = 1;?>
<div class="cards">
    <?php foreach ($products as $product):?>
        <?php if($id_cat == $product['category_id'] || $id_categories == $product['category_id']):?>
            <?php $flug = false; ?>
            <div class="cardsss">
            <h2>категория</h2>
                <?php foreach ($categoties as $categoty):?>
                <?php if($categoty['id'] == $id_categories):?>
                    <p><?= $categoty['name']?></p>
                 <?php endif;?>
                <?php endforeach;?>
            <p><?= $name_cat?></p>
                <?php var_dump($flug); ?>
                <a href="product.php?name=<?= $product['name']?>&&description=<?= $product['description']?>"><?= $product['name']?></a>
                </div>


        <?php elseif($flug):?>
            <div class="card">
                <h2><?= $product['name']?></h2>
                <p hidden><?= $product['description']?></p>
                <a href="product.php?name=<?= $product['name']?>&&description=<?= $product['description']?>">Подробнее</a>
            </div>
        <?php endif;?>
    <?php endforeach;?>
<?=$flug?>
</div>


</body>
</html>