<?php
/** @var PDO $pdo */
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/db.php';

$name = $_POST['name'];
$id = $_POST['id'];

$pdo->query("UPDATE `products` SET `name` = '$name' WHERE `id` = '$id'");

header('Location: /product/');