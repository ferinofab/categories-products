<?php


/** @var PDO $pdo */
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$id = $_POST['id'];


function IsChecked($chkname,$value)
{
    if(!empty($_POST[$chkname]))
    {
        foreach($_POST[$chkname] as $chkval)
        {
            if($chkval == $value)
            {
                return true;
            }
        }
    }
    return false;
}



if(IsChecked('checkbox',true))
{
    $pdo->query("UPDATE `products` SET `popular` = true WHERE `id` = '$id'");

}
//или использовать в расчете ...





    $pdo->query('INSERT INTO categories(name) VALUES("' . !$bool . '") ');

