<?php
/** @var PDO $pdo */
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$name = $_POST["name"];
$date = $_POST["date"];

$pdo->query('INSERT INTO products(name, date) VALUES("' . $name . '", "' . $date . '")')->fetch(PDO::FETCH_ASSOC);

header('Location: /product/index.php');