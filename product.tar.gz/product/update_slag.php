<?php
/** @var PDO $pdo */
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/db.php';

$slug = $_POST['name'];
$id = $_POST['id'];

$pdo->query("UPDATE `products` SET `slug` = '$slug' WHERE `id` = '$id'");

header('Location: /product/index.php');