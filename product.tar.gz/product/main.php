<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$products= $pdo->query("SELECT * FROM `products`")->fetchAll(PDO::FETCH_ASSOC);
$categories= $pdo->query("SELECT * FROM `categories`")->fetchAll(PDO::FETCH_ASSOC);

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>Список популярных товаров</h2>
    <div class="list">
        <?php foreach ($products as $product):?>
            <a href="product.php?name=<?= $product['name']?>&&description=<?= $product['description']?>"><?php
                if($product['popular'] == 1){
                    echo $product['name'];
                }
                ?></a>
        <?php endforeach;?>
    </div>
    <h2>Список категроий</h2>
    <div class="category">
        <?php foreach ($categories as $category):?>
            <ul>
                <a href="products.php?id=<?= $category['id']?>&&name=<?= $category['name']?>"><li><?= $category['name']?></li></a>
            </ul>
        <?php endforeach;?>
    </div>
    <a href="products.php">Перейти в каталог товаров</a>
</body>
</html>
