<?php
/** @var PDO $pdo */

$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$products= $pdo->query("SELECT * FROM `products`")->fetchAll(PDO::FETCH_ASSOC);


function autoSlag($str) {

    $rus=array('А','Б','В','Г','Д','Е','Ё','Ж','З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х','Ц','Ч','Ш','Щ','Ъ','Ы','Ь','Э','Ю','Я','а','б','в','г','д','е','ё','ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','ш','щ','ъ','ы','ь','э','ю','я',' ');

    $lat=array('a','b','v','g','d','e','e','gh','z','i','y','k','l','m','n','o','p','r','s','t','u','f','h','c','ch','sh','sch','y','y','y','e','yu','ya','a','b','v','g','d','e','e','gh','z','i','y','k','l','m','n','o','p','r','s','t','u','f','h','c','ch','sh','sch','y','y','y','e','yu','ya',' ');

    $str = str_replace($rus, $lat, $str); // перевеодим на английский
    $str = str_replace('-', '', $str); // удаляем все исходные "-"
    $slug = preg_replace('/[^A-Za-z0-9-]+/', '-', $str); // заменяет все символы и пробелы на "-"
    return $slug;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>Товары</h1>
<a href="create.php">Добавление продукта</a>
<table>
    <thead>
    <tr>
        <td>#</td>
        <td>Название</td>
        <td>Описание</td>
        <td>Популярный товар</td>
        <td>Slug</td>
        <td>дата</td>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($products as $product): ?>
        <tr>
            <td><?= $product['id'] ?></td>
            <td>
                <?= $product['name'] ?>
            </td>
            <td>
                <?= $product['description']?>
            </td>
            <td>
                <?php if($product['popular']):?>
                    <p>да</p>
                <?php else:?>
                    <p>нет</p>
                <?php endif;?>

            </td>
            <td>
                <?php if ($product['slug'] == null):?>
                    <?php
                    $slug = autoSlag($product['name']);
                   echo $slug;

                    ?>
                <?php else:?>
                    <?= $product['slug']?>
                <?php endif;?>
            </td>
            <td>
                <?=$product['date']?>
            </td>
            <td>
                <a href="delete.php?id=<?= $product['id'] ?>">Удалить</a>
            </td>
            <td>
                <a href="/product/edit.php?id=<?= $product['id'] ?>">Редактировать</a>
            </td>
            <td>
                <a href="/product/edit_description.php?id=<?= $product['id'] ?>">Редактировать описание</a>
            </td>
            <td>
                <a href="/product/slug.php?id=<?= $product['id'] ?>">Редактировать slug</a>
            </td>
            <td>
                <a href="">редактировать дату</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</body>
</html>