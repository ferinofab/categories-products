<?php

/** @var PDO $pdo */
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/db.php';

$description = $_POST['name'];
$id = $_POST['id'];

$pdo->query("UPDATE `products` SET `description` = '$description' WHERE `id` = '$id'");

header('Location: /product/');