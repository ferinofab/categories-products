<?php
$products = require  $_SERVER['DOCUMENT_ROOT'] . '/queries/category.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Добавление продукта</h1>
<form action="action.php" method="post">
    <input type="text" name="name" placeholder="Название">
    <input type="text" name="date" placeholder="Дата гггг-мм-дд">
    <input type="submit">
</form>
</body>
</html>